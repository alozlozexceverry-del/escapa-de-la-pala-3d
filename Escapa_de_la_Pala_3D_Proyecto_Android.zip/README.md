# Escapa de la Pala 3D - Proyecto Android

Este proyecto envuelve el juego HTML original con Capacitor.

## Contenido
- `www/index.html`: juego original.
- `package.json`: dependencias de Capacitor.
- `capacitor.config.ts`: nombre e identificador de la app.
- `.github/workflows/android.yml`: compilación automática en GitHub Actions.

## Compilación
Al subir el contenido de esta carpeta a un repositorio GitHub y ejecutar el workflow
"Build Android APK and AAB", se generan:
- APK debug: instalable para pruebas.
- AAB release: se genera sin firma; para publicar en Google Play hay que configurar
  una clave de firma (keystore) y firmar el bundle.

El juego carga Tailwind, Three.js, Tone.js y Google Fonts desde internet.
Por eso necesita conexión a internet para cargar esas bibliotecas.
