import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.alojuego.escapadelapala',
  appName: 'Escapa de la Pala 3D',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
